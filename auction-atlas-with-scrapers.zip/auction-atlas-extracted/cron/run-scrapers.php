#!/usr/bin/env php
<?php

/**
 * Scraper Cron Job
 * 
 * Run this script periodically to scrape auction data
 * 
 * Usage:
 *   php run-scrapers.php           - Run all scrapers
 *   php run-scrapers.php gobid     - Run only GoBid scraper
 *   php run-scrapers.php --dry-run - Test without saving to database
 * 
 * Setup cron to run every week (Sunday at 2am):
 *   0 2 * * 0 /usr/bin/php /path/to/run-scrapers.php >> /var/log/auction-scraper.log 2>&1
 */

// Get command line arguments
$args = $argv;
array_shift($args); // Remove script name

$dryRun = in_array('--dry-run', $args);
$verbose = in_array('--verbose', $args) || in_array('-v', $args);

// Remove flags from args
$args = array_filter($args, function($arg) {
    return !in_array($arg, ['--dry-run', '--verbose', '-v']);
});

// Database configuration
$dbConfig = [
    'host' => getenv('DB_HOST') ?: 'localhost',
    'dbname' => getenv('DB_NAME') ?: 'auction_atlas',
    'username' => getenv('DB_USER') ?: 'root',
    'password' => getenv('DB_PASS') ?: '',
];

// Include required files
$basePath = dirname(__DIR__);
require_once $basePath . '/includes/scraper/ScraperManager.php';

// Connect to database
$pdo = null;
if (!$dryRun) {
    try {
        $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['dbname']};charset=utf8mb4";
        $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
        if ($verbose) {
            echo "Database connected successfully.\n";
        }
    } catch (PDOException $e) {
        if ($verbose) {
            echo "Warning: Could not connect to database: " . $e->getMessage() . "\n";
            echo "Running in dry-run mode.\n";
        }
        $dryRun = true;
    }
}

// Create scraper manager
$manager = new ScraperManager($pdo);

// Run specific scraper or all
if (!empty($args)) {
    $scraperName = ucfirst(strtolower($args[0]));
    
    if ($verbose) {
        echo "Running scraper: {$scraperName}\n";
    }
    
    $result = $manager->runScraper($scraperName);
    
    if ($result) {
        echo "Status: {$result['status']}\n";
        echo "Auctions found: {$result['auctions_found']}\n";
        
        if ($result['status'] === 'error') {
            echo "Error: {$result['error']}\n";
            exit(1);
        }
    } else {
        echo "Scraper '{$scraperName}' not found.\n";
        exit(1);
    }
} else {
    if ($verbose) {
        echo "Running all scrapers...\n";
    }
    
    $results = $manager->runAll();
    
    echo "Scraping complete!\n";
    echo "Total auctions found: {$results['total_auctions']}\n";
    echo "\nResults by source:\n";
    
    foreach ($results['scrapers'] as $source => $data) {
        $status = $data['status'];
        $count = $data['auctions_found'] ?? 0;
        $duration = $data['duration_seconds'] ?? 0;
        
        echo "  - {$source}: {$count} auctions ({$status}) in {$duration}s\n";
    }
    
    if (!empty($results['errors'])) {
        echo "\nErrors:\n";
        foreach ($results['errors'] as $error) {
            echo "  - {$error['source']}: {$error['error']}\n";
        }
    }
}

// Cleanup old events (optional)
// $manager->cleanupOldEvents(30);

exit(0);
