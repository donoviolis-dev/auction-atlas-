<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auction Calendar - Auction Atlas</title>
    
    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/main.min.css" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
        }
        
        .header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: white;
            padding: 20px 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }
        
        .header p {
            opacity: 0.8;
            font-size: 0.9rem;
        }
        
        .filters {
            background: white;
            padding: 15px 30px;
            border-bottom: 1px solid #eee;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        
        .filters label {
            font-weight: 500;
            color: #333;
        }
        
        .filters select {
            padding: 8px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            min-width: 150px;
        }
        
        .filters button {
            padding: 8px 20px;
            background: #e74c3c;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .filters button:hover {
            background: #c0392b;
        }
        
        .calendar-container {
            padding: 20px;
            max-width: 1400px;
            margin: 0 auto;
        }
        
        #calendar {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .fc .fc-toolbar-title {
            font-size: 1.5rem;
        }
        
        .fc .fc-button {
            background: #1a1a2e;
            border-color: #1a1a2e;
        }
        
        .fc .fc-button:hover {
            background: #16213e;
            border-color: #16213e;
        }
        
        .fc .fc-button-primary:not(:disabled).fc-button-active,
        .fc .fc-button-primary:not(:disabled):active {
            background: #e74c3c;
            border-color: #e74c3c;
        }
        
        .fc-event {
            cursor: pointer;
            border: none;
        }
        
        .fc-event-main {
            padding: 2px 5px;
        }
        
        .source-badge {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
            font-weight: bold;
            margin-right: 5px;
        }
        
        .source-gobid { background: #27ae60; color: white; }
        .source-aucor { background: #3498db; color: white; }
        .source-bidders-choice { background: #9b59b6; color: white; }
        .source-claremart { background: #f39c12; color: white; }
        .source-auction-operation { background: #1abc9c; color: white; }
        
        .event-popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            z-index: 1000;
            max-width: 500px;
            width: 90%;
            display: none;
        }
        
        .event-popup.show {
            display: block;
        }
        
        .event-popup h3 {
            margin-bottom: 15px;
            color: #1a1a2e;
        }
        
        .event-popup .detail {
            margin-bottom: 10px;
            color: #555;
        }
        
        .event-popup .detail strong {
            color: #333;
        }
        
        .event-popup .close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
        }
        
        .event-popup .view-btn {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 25px;
            background: #e74c3c;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            display: none;
        }
        
        .overlay.show {
            display: block;
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .legend {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 15px;
            justify-content: center;
        }
        
        .legend-item {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 12px;
            color: #666;
        }
        
        .legend-color {
            width: 15px;
            height: 15px;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📅 Auction Calendar</h1>
        <p>Upcoming auctions from across South Africa</p>
    </div>
    
    <div class="filters">
        <label>Filter by Source:</label>
        <select id="sourceFilter">
            <option value="">All Sources</option>
            <option value="GoBid">GoBid</option>
            <option value="Aucor Auctioneers">Aucor Auctioneers</option>
            <option value="Auction Operation">Auction Operation</option>
            <option value="Bidders Choice">Bidders Choice</option>
            <option value="Claremart Auctioneers">Claremart Auctioneers</option>
            <option value="High Street Auctions">High Street Auctions</option>
            <option value="SA Auction Group">SA Auction Group</option>
            <option value="WH Auctioneers">WH Auctioneers</option>
            <option value="Cahi Auctioneers">Cahi Auctioneers</option>
            <option value="Nuco Auctioneers">Nuco Auctioneers</option>
            <option value="WCT Auctions">WCT Auctions</option>
            <option value="AuctionInc">AuctionInc</option>
        </select>
        
        <label>Filter by Location:</label>
        <select id="locationFilter">
            <option value="">All Locations</option>
            <option value="National">National</option>
            <option value="Johannesburg">Johannesburg</option>
            <option value="Cape Town">Cape Town</option>
            <option value="Durban">Durban</option>
            <option value="Pretoria">Pretoria</option>
        </select>
        
        <button onclick="refreshCalendar()">🔄 Refresh</button>
    </div>
    
    <div class="calendar-container">
        <div id="calendar"></div>
        
        <div class="legend">
            <div class="legend-item">
                <div class="legend-color" style="background: #27ae60;"></div>
                <span>GoBid</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #3498db;"></div>
                <span>Aucor</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #9b59b6;"></div>
                <span>Bidders Choice</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #f39c12;"></div>
                <span>Claremart</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #1abc9c;"></div>
                <span>Auction Operation</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #e74c3c;"></div>
                <span>High Street</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #e67e22;"></div>
                <span>SA Auction Group</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #34495e;"></div>
                <span>WH Auctioneers</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #16a085;"></div>
                <span>Cahi</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #8e44ad;"></div>
                <span>Nuco</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #d35400;"></div>
                <span>WCT</span>
            </div>
            <div class="legend-item">
                <div class="legend-color" style="background: #2c3e50;"></div>
                <span>AuctionInc</span>
            </div>
        </div>
    </div>
    
    <!-- Event Popup -->
    <div class="overlay" id="overlay"></div>
    <div class="event-popup" id="eventPopup">
        <button class="close-btn" onclick="closePopup()">&times;</button>
        <h3 id="popupTitle">Auction Title</h3>
        <div class="detail"><strong>📅 Date:</strong> <span id="popupDate"></span></div>
        <div class="detail"><strong>📍 Location:</strong> <span id="popupLocation"></span></div>
        <div class="detail"><strong>🏷️ Source:</strong> <span id="popupSource"></span></div>
        <a href="#" target="_blank" class="view-btn" id="popupLink">View Auction</a>
    </div>
    
    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>
    
    <script>
        let calendar;
        
        // Source colors mapping
        const sourceColors = {
            'GoBid': '#27ae60',
            'Aucor Auctioneers': '#3498db',
            'Auction Operation': '#1abc9c',
            'Bidders Choice': '#9b59b6',
            'Claremart Auctioneers': '#f39c12',
            'High Street Auctions': '#e74c3c',
            'SA Auction Group': '#e67e22',
            'WH Auctioneers': '#34495e',
            'Cahi Auctioneers': '#16a085',
            'Nuco Auctioneers': '#8e44ad',
            'WCT Auctions': '#d35400',
            'AuctionInc': '#2c3e50'
        };
        
        function getSourceClass(source) {
            const s = source.toLowerCase().replace(/\s+/g, '-');
            return 'source-' + s;
        }
        
        function getSourceColor(source) {
            return sourceColors[source] || '#666';
        }
        
        async function fetchEvents(start, end) {
            const source = document.getElementById('sourceFilter').value;
            const location = document.getElementById('locationFilter').value;
            
            let url = '/api/calendar.php?start=' + start + '&end=' + end;
            
            if (source) url += '&source=' + encodeURIComponent(source);
            if (location) url += '&location=' + encodeURIComponent(location);
            
            try {
                const response = await fetch(url);
                const data = await response.json();
                return data.events || [];
            } catch (error) {
                console.error('Error fetching events:', error);
                return [];
            }
        }
        
        function initCalendar() {
            const calendarEl = document.getElementById('calendar');
            
            calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listMonth'
                },
                initialDate: new Date(),
                events: async function(info, successCallback, failureCallback) {
                    try {
                        const events = await fetchEvents(
                            info.startStr,
                            info.endStr
                        );
                        
                        const formattedEvents = events.map(event => ({
                            id: event.id,
                            title: event.title,
                            start: event.start,
                            backgroundColor: getSourceColor(event.source),
                            borderColor: getSourceColor(event.source),
                            extendedProps: {
                                location: event.location,
                                source: event.source,
                                url: event.url
                            }
                        }));
                        
                        successCallback(formattedEvents);
                    } catch (error) {
                        failureCallback(error);
                    }
                },
                eventClick: function(info) {
                    showEventPopup(info.event);
                },
                eventDidMount: function(info) {
                    // Add source badge to event
                    const source = info.event.extendedProps.source;
                    const badge = document.createElement('span');
                    badge.className = 'source-badge ' + getSourceClass(source);
                    badge.textContent = source;
                    info.el.insertBefore(badge, info.el.firstChild);
                }
            });
            
            calendar.render();
        }
        
        function showEventPopup(event) {
            const props = event.extendedProps;
            
            document.getElementById('popupTitle').textContent = event.title;
            document.getElementById('popupDate').textContent = event.start.toLocaleString();
            document.getElementById('popupLocation').textContent = props.location || 'Unconfirmed';
            document.getElementById('popupSource').textContent = props.source;
            document.getElementById('popupLink').href = props.url || '#';
            
            document.getElementById('overlay').classList.add('show');
            document.getElementById('eventPopup').classList.add('show');
        }
        
        function closePopup() {
            document.getElementById('overlay').classList.remove('show');
            document.getElementById('eventPopup').classList.remove('show');
        }
        
        function refreshCalendar() {
            calendar.refetchEvents();
        }
        
        // Event listeners
        document.getElementById('sourceFilter').addEventListener('change', refreshCalendar);
        document.getElementById('locationFilter').addEventListener('change', refreshCalendar);
        document.getElementById('overlay').addEventListener('click', closePopup);
        
        // Close popup on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') closePopup();
        });
        
        // Initialize
        document.addEventListener('DOMContentLoaded', initCalendar);
    </script>
</body>
</html>
