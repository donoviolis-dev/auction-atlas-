<?php

/**
 * Calendar Events API
 * 
 * Returns auction events in FullCalendar format
 * 
 * Usage:
 * - GET /api/calendar.php - Get all upcoming events
 * - GET /api/calendar.php?start=2026-03-01&end=2026-03-31 - Date range filter
 * - GET /api/calendar.php?source=GoBid - Filter by source
 * - GET /api/calendar.php?location=Johannesburg - Filter by location
 * 
 * FullCalendar format:
 * {
 *   "id": 1,
 *   "title": "GoBid Auction - RNHYZ1YH (70 lots) - National",
 *   "start": "2026-03-16T19:00:00",
 *   "location": "National",
 *   "source": "GoBid",
 *   "url": "https://www.gobid.co.za/live/catalogue/RNHYZ1YH"
 * }
 */

// Set headers for JSON API
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only allow GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Database configuration - update these for your environment
$dbConfig = [
    'host' => getenv('DB_HOST') ?: 'localhost',
    'dbname' => getenv('DB_NAME') ?: 'auction_atlas',
    'username' => getenv('DB_USER') ?: 'root',
    'password' => getenv('DB_PASS') ?: '',
];

try {
    // Create PDO connection
    $dsn = "mysql:host={$dbConfig['host']};dbname={$dbConfig['dbname']};charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    $pdo = new PDO($dsn, $dbConfig['username'], $dbConfig['password'], $options);
    
} catch (PDOException $e) {
    // If no database, use demo data
    $pdo = null;
}

// Get query parameters
$start = $_GET['start'] ?? null;
$end = $_GET['end'] ?? null;
$source = $_GET['source'] ?? null;
$location = $_GET['location'] ?? null;
$limit = (int)($_GET['limit'] ?? 100);

// Build query
$sql = "SELECT id, external_id, title, event_date, location, source_name, source_url 
        FROM calendar_events 
        WHERE 1=1";

$params = [];

if ($start) {
    $sql .= " AND event_date >= :start";
    $params[':start'] = $start;
}

if ($end) {
    $sql .= " AND event_date <= :end";
    $params[':end'] = $end . ' 23:59:59';
}

if ($source) {
    $sql .= " AND source_name = :source";
    $params[':source'] = $source;
}

if ($location) {
    $sql .= " AND location LIKE :location";
    $params[':location'] = '%' . $location . '%';
}

// Only show future events by default
if (!$start) {
    $sql .= " AND event_date >= NOW()";
}

$sql .= " ORDER BY event_date ASC LIMIT :limit";
$params[':limit'] = $limit;

$events = [];

if ($pdo) {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        while ($row = $stmt->fetch()) {
            $events[] = [
                'id' => $row['id'],
                'title' => $row['title'],
                'start' => $row['event_date'],
                'location' => $row['location'],
                'source' => $row['source_name'],
                'url' => $row['source_url'],
            ];
        }
    } catch (PDOException $e) {
        // Log error but continue with demo data
        error_log("Database error: " . $e->getMessage());
    }
}

// If no events from database, return demo data for testing
if (empty($events)) {
    $events = getDemoEvents();
}

// Return response
echo json_encode([
    'success' => true,
    'count' => count($events),
    'events' => $events,
]);

/**
 * Get demo events for testing when database is not available
 */
function getDemoEvents(): array {
    return [
        [
            'id' => 1,
            'title' => 'GoBid Auction - RNHYZ1YH (70 lots)',
            'start' => '2026-03-16T19:00:00',
            'location' => 'National',
            'source' => 'GoBid',
            'url' => 'https://www.gobid.co.za/live/catalogue/RNHYZ1YH'
        ],
        [
            'id' => 2,
            'title' => 'GoBid Auction - TOTXLDPC (180 lots)',
            'start' => '2026-03-17T09:00:00',
            'location' => 'National',
            'source' => 'GoBid',
            'url' => 'https://www.gobid.co.za/live/catalogue/TOTXLDPC'
        ],
        [
            'id' => 3,
            'title' => 'GoBid Auction - PBSX3KJJ',
            'start' => '2026-03-18T09:00:00',
            'location' => 'National',
            'source' => 'GoBid',
            'url' => 'https://www.gobid.co.za/live/catalogue/PBSX3KJJ'
        ],
        [
            'id' => 4,
            'title' => 'GoBid Auction - 19GXVXCZ',
            'start' => '2026-03-18T19:00:00',
            'location' => 'National',
            'source' => 'GoBid',
            'url' => 'https://www.gobid.co.za/live/catalogue/19GXVXCZ'
        ],
        [
            'id' => 5,
            'title' => 'Movable Auction: Trucks & Equipment',
            'start' => '2026-03-17T14:00:00',
            'location' => 'Unconfirmed',
            'source' => 'Bidders Choice',
            'url' => 'https://www.biddersonline.co.za/auction'
        ],
        [
            'id' => 6,
            'title' => 'Commercial - Retail in Montagu',
            'start' => '2026-04-29T09:00:00',
            'location' => 'Montagu',
            'source' => 'Claremart Auctioneers',
            'url' => 'https://claremart.com/Auctions'
        ],
        [
            'id' => 7,
            'title' => 'Bidder Mania - eMalahleni (Witbank)',
            'start' => '2026-03-14T17:00:00',
            'location' => '81 Marelden Industrial Park, Voortrekker Road',
            'source' => 'Aucor Auctioneers',
            'url' => 'https://live.aucor.com/auctions'
        ],
    ];
}
