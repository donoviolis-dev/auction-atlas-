-- Auction Atlas - Calendar Events Database Schema
-- Run this SQL to create the necessary tables for storing scraped auction data

-- Table for tracking scraper sources
CREATE TABLE IF NOT EXISTS scraper_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    base_url VARCHAR(500) NOT NULL,
    scraper_class VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_scraped DATETIME NULL,
    success_rate DECIMAL(5,2) DEFAULT 100.00,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_active (is_active),
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default scraper sources
INSERT INTO scraper_sources (name, base_url, scraper_class) VALUES
('GoBid', 'https://www.gobid.co.za', 'GoBidScraper'),
('Aucor Auctioneers', 'https://live.aucor.com', 'AucorScraper'),
('Auction Operation', 'https://live.auctionoperation.co.za', 'AuctionOperationScraper'),
('Bidders Choice', 'https://www.biddersonline.co.za', 'BiddersChoiceScraper'),
('Claremart Auctioneers', 'https://claremart.com', 'ClaremartScraper'),
('High Street Auctions', 'https://www.highstreetauctions.com', 'HighStreetScraper'),
('SA Auction Group', 'https://www.saauctiongroup.co.za', 'SAAuctionGroupScraper'),
('WH Auctioneers', 'https://www.whauctions.com', 'WHAuctioneersScraper'),
('Cahi Auctioneers', 'https://www.cahi.co.za', 'CahiScraper'),
('Nuco Auctioneers', 'https://bidding.nucoauctioneers.com', 'NucoScraper'),
('WCT Auctions', 'https://online.wctauctions.co.za', 'WCTAuctionsScraper'),
('AuctionInc', 'https://www.auctioninc.co.za', 'AuctionIncScraper')
ON DUPLICATE KEY UPDATE base_url = VALUES(base_url), scraper_class = VALUES(scraper_class);

-- Main calendar events table
CREATE TABLE IF NOT EXISTS calendar_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_id INT NULL,
    external_id VARCHAR(255) NOT NULL,
    title VARCHAR(500) NOT NULL,
    event_date DATETIME NOT NULL,
    location VARCHAR(255) DEFAULT 'Unconfirmed',
    source_name VARCHAR(255) NOT NULL,
    source_url VARCHAR(500) DEFAULT '',
    scraped_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (source_id) REFERENCES scraper_sources(id) ON DELETE SET NULL,
    
    UNIQUE KEY uk_external_id (external_id),
    INDEX idx_event_date (event_date),
    INDEX idx_source (source_name),
    INDEX idx_location (location),
    INDEX idx_title (title(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for tracking scrape logs
CREATE TABLE IF NOT EXISTS scrape_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_id INT NULL,
    source_name VARCHAR(255) NOT NULL,
    status ENUM('success', 'partial', 'failed') DEFAULT 'success',
    items_found INT DEFAULT 0,
    errors JSON NULL,
    duration_seconds INT DEFAULT 0,
    scraped_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (source_id) REFERENCES scraper_sources(id) ON DELETE SET NULL,
    
    INDEX idx_scraped_at (scraped_at),
    INDEX idx_status (status),
    INDEX idx_source (source_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- View for upcoming events (useful for calendar)
CREATE OR REPLACE VIEW upcoming_calendar_events AS
SELECT 
    id,
    external_id,
    title,
    event_date,
    location,
    source_name,
    source_url
FROM calendar_events
WHERE event_date >= NOW()
ORDER BY event_date ASC;

-- Procedure to run all scrapers (can be called from cron)
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS run_all_scrapers()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE scraper_name VARCHAR(255);
    DECLARE scraper_url VARCHAR(500);
    DECLARE cur CURSOR FOR 
        SELECT name, base_url FROM scraper_sources WHERE is_active = TRUE;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- Log start
    INSERT INTO scrape_logs (source_name, status, items_found, scraped_at)
    VALUES ('SYSTEM', 'success', 0, NOW());
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO scraper_name, scraper_url;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Note: The actual scraping is done via PHP, this is just for logging
        -- In practice, you'd call your PHP scraper here or via external cron
        
    END LOOP;
    
    CLOSE cur;
END //
DELIMITER ;
