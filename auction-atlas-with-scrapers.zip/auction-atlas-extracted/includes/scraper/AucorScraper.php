<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * Aucor Auction Scraper
 * 
 * Scrapes upcoming auctions from https://live.aucor.com
 * Note: Auction Operation (https://live.auctionoperation.co.za) uses the same platform
 */
class AucorScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://live.aucor.com';
        $this->sourceName = 'Aucor Auctioneers';
    }
    
    public function getSourceName(): string {
        return 'Aucor Auctioneers';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/auctions';
    }
    
    protected function getItemSelector(): string {
        return '.auction-row-header, div[ng-repeat*="auction"]';
    }
    
    /**
     * Extract title from Aucor auction element
     */
    protected function extractTitle($el): ?string {
        // Title is in .title element
        $title = $el->find('.title', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try alternative selectors
        $title = $el->find('.auction-title', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from Aucor auction element
     * 
     * Date format: "Closing Mar 14, 2026 at 5 PM SAST" or in subtitle
     */
    protected function extractDate($el): ?DateTime {
        $subtitle = $el->find('.subtitle', 0)?->text();
        
        if (!$subtitle) {
            return null;
        }
        
        // Try to extract closing date
        $date = DateParser::extractClosingDate($subtitle);
        if ($date) {
            return $date;
        }
        
        // Try general date parsing
        return DateParser::parseFromText($subtitle, '/(\w+\s+\d+,?\s+\d+\s*[\d:]*\s*(?:AM|PM)?)/i');
    }
    
    /**
     * Extract location from Aucor auction element
     * 
     * Location is in subtitle after the date/venue
     */
    protected function extractLocation($el): ?string {
        $subtitle = $el->find('.subtitle', 0)?->text();
        
        if (!$subtitle) {
            return 'Unconfirmed';
        }
        
        // Pattern: "Closing Mar 14, 2026 at 5 PM SAST • 81 Marelden Industrial Park Voortrekker Road •"
        // Extract address after the last •
        if (preg_match('/•\s*([^•]+)\s*$/', $subtitle, $matches)) {
            $location = trim($matches[1]);
            // Remove timer element if present
            $location = preg_replace('/\s*\d+H\s*\d+M.*$/i', '', $location);
            
            if (!empty($location)) {
                return $this->cleanText($location);
            }
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL for Aucor auction
     */
    protected function getSourceUrl($el): string {
        // Try to find link in view-lots button
        $link = $el->find('a[href*="/auctions/"]', 0);
        
        if ($link && isset($link->href)) {
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
