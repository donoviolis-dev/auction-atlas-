<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * High Street Auctions Scraper
 * 
 * Scrapes upcoming auctions from https://www.highstreetauctions.com
 */
class HighStreetScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://www.highstreetauctions.com';
        $this->sourceName = 'High Street Auctions';
    }
    
    public function getSourceName(): string {
        return 'High Street Auctions';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/calendar';
    }
    
    protected function getItemSelector(): string {
        return '.decm-events-details, .event-item, article.event';
    }
    
    /**
     * Extract title from High Street auction element
     */
    protected function extractTitle($el): ?string {
        // Try entry-title first
        $title = $el->find('.entry-title', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try h2
        $title = $el->find('h2', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try h3
        $title = $el->find('h3', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from High Street auction element
     */
    protected function extractDate($el): ?DateTime {
        // Try decm-show-detail-center
        $container = $el->find('.decm-show-detail-center', 0);
        
        if ($container) {
            // Get date
            $dateText = $container->find('.decm_date', 0)?->text();
            $timeText = $container->find('.decm_date', 1)?->text();
            
            if ($dateText) {
                if ($timeText) {
                    $dateText .= ' ' . $timeText;
                }
                return DateParser::parse($dateText);
            }
        }
        
        // Try ecs-eventDate
        $dateText = $el->find('.ecs-eventDate .decm_date', 0)?->text();
        $timeText = $el->find('.ecs-eventTime .decm_date', 0)?->text();
        
        if ($dateText) {
            if ($timeText) {
                $dateText .= ' ' . $timeText;
            }
            return DateParser::parse($dateText);
        }
        
        return null;
    }
    
    /**
     * Extract location from High Street auction element
     */
    protected function extractLocation($el): ?string {
        // Try ecs-venue
        $location = $el->find('.ecs-venue .decm_venue', 0)?->text();
        
        if ($location) {
            return $this->cleanText($location);
        }
        
        // Try venue class
        $location = $el->find('.venue', 0)?->text();
        if ($location) {
            return $this->cleanText($location);
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/auction/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
