<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * Bidders Choice Scraper
 * 
 * Scrapes upcoming auctions from https://www.biddersonline.co.za/auction
 */
class BiddersChoiceScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://www.biddersonline.co.za';
        $this->sourceName = 'Bidders Choice';
    }
    
    public function getSourceName(): string {
        return 'Bidders Choice';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/auction';
    }
    
    protected function getItemSelector(): string {
        return '.p-4, div[class*="mb-"] h3, div[class*="flex-col"], div[class*="rounded"]';
    }
    
    /**
     * Extract title from Bidders Choice auction element
     * 
     * Title format: "Movable Auction: Trucks, LDV's & Equipment – Afternoon Auction 1 (2PM - 3PM) : Close 17 March 2026"
     */
    protected function extractTitle($el): ?string {
        // Try h3 first
        $title = $el->find('h3', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try heading elements
        $title = $el->find('.font-semibold', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try any heading
        $title = $el->find('h4, h5, h6', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from Bidders Choice auction element
     * 
     * Date patterns: "Open: 12 Mar 2026 08:00" and "Closing: 17 Mar 2026 14:00"
     */
    protected function extractDate($el): ?DateTime {
        $text = $el->text();
        
        // Try closing date first (most important)
        $date = DateParser::extractClosingDate($text);
        if ($date) {
            return $date;
        }
        
        // Try start date
        $date = DateParser::extractStartDate($text);
        if ($date) {
            return $date;
        }
        
        return null;
    }
    
    /**
     * Extract location from Bidders Choice auction element
     */
    protected function extractLocation($el): ?string {
        // Location may not be prominent in the listing
        // Check for location-related elements
        
        // Try to find location in icon + text pattern
        $locationIcon = $el->find('.fa-map-marker, [class*="map"]', 0);
        
        if ($locationIcon) {
            // Get sibling or parent text
            $parent = $locationIcon->parent();
            if ($parent) {
                $text = $this->cleanText($parent->text());
                // Remove the icon character
                $text = preg_replace('/[\s\S]*?(?:map-marker|location)[\s\S]*/i', '', $text);
                if (!empty(trim($text))) {
                    return trim($text);
                }
            }
        }
        
        // Look for location text patterns
        $text = $el->text();
        if (preg_match('/Location[:\s]+([A-Za-z\s,]+)/i', $text, $matches)) {
            return trim($matches[1]);
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL for Bidders Choice auction
     */
    protected function getSourceUrl($el): string {
        // Try to find detail link
        $link = $el->find('a[href*="/auction/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        // Try details link
        $link = $el->find('a[href*="/details"]', 0);
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
