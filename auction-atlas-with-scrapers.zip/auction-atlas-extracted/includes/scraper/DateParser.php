<?php

/**
 * Date Parser Utility
 * 
 * Handles various date formats from South African auction websites
 */
class DateParser {
    
    /**
     * All possible date formats to try
     */
    private static array $formats = [
        // Full datetime formats
        'l, d M Y H:i'    => 'Monday, 16 Mar 2026 19:00',
        'd M Y H:i'       => '16 Mar 2026 19:00',
        'd F Y \a\t H:i'  => '16 March 2026 at 19:00',
        'F d, Y \a\t h:i A' => 'March 16, 2026 at 07:00 PM',
        'M d, Y h:i A'    => 'Mar 16, 2026 07:00 PM',
        'd F Y H:i'       => '16 March 2026 19:00',
        
        // Date only
        'd F Y'           => '16 March 2026',
        'l, M d, Y'       => 'Mon, Mar 16, 2026',
        'l, d F Y'        => 'Monday, 16 March 2026',
        'M d, Y'          => 'Mar 16, 2026',
        'd M Y'           => '16 Mar 2026',
        'F d, Y'          => 'March 16, 2026',
        
        // Numeric formats
        'd/m/Y H:i'       => '16/03/2026 19:00',
        'd/m/Y'           => '16/03/2026',
        'Y-m-d H:i:s'     => '2026-03-16 19:00:00',
        'Y-m-d H:i'       => '2026-03-16 19:00',
        'Y-m-d'           => '2026-03-16',
    ];

    /**
     * Parse a date string into a DateTime object
     * 
     * @param string $dateText The date string to parse
     * @return DateTime|null The parsed DateTime or null if parsing fails
     */
    public static function parse(string $dateText): ?DateTime {
        if (empty(trim($dateText))) {
            return null;
        }

        $dateText = trim($dateText);
        // Normalize whitespace
        $dateText = preg_replace('/\s+/', ' ', $dateText);
        
        // Remove common timezone suffixes
        $dateText = preg_replace('/\s*(SAST|EST|GMT|Z)\s*/i', '', $dateText);
        
        // Try each format
        foreach (self::$formats as $format => $example) {
            $dt = DateTime::createFromFormat($format, $dateText);
            if ($dt !== false) {
                return $dt;
            }
        }
        
        // Fallback to strtotime for natural language
        $ts = strtotime($dateText);
        if ($ts !== false && $ts > 0) {
            return new DateTime(date('Y-m-d H:i', $ts));
        }
        
        return null;
    }

    /**
     * Parse a date from multiple possible patterns in text
     * 
     * @param string $text The full text to search for date
     * @param string $pattern Regex pattern to match
     * @return DateTime|null The parsed DateTime or null
     */
    public static function parseFromText(string $text, string $pattern): ?DateTime {
        if (preg_match($pattern, $text, $matches)) {
            return self::parse($matches[1]);
        }
        return null;
    }

    /**
     * Common date extraction patterns for auction sites
     */
    public static function extractClosingDate(string $text): ?DateTime {
        $patterns = [
            '/Closing[:\s]+(\d+\s+\w+\s+\d+\s*[\d:]*\s*(?:AM|PM)?)/i',
            '/Close\s+(\d+\s+\w+\s+\d+)/i',
            '/Bidding End Time[:\s]+(\w+\s+\d+\s+\w+\s+\d+\s*@\s*[\d:]+)/i',
            '/ends?\s+(\w+\s+\d+,?\s+\d+\s+[\d:]+)/i',
            '/ending\s+(\w+\s+\d+,?\s+\d+)/i',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $matches)) {
                $result = self::parse($matches[1]);
                if ($result) {
                    return $result;
                }
            }
        }
        
        return null;
    }

    /**
     * Extract start/opening date from text
     */
    public static function extractStartDate(string $text): ?DateTime {
        $patterns = [
            '/Opening[:\s]+(\d+\s+\w+\s+\d+\s*[\d:]*\s*(?:AM|PM)?)/i',
            '/Open[:\s]+(\d+\s+\w+\s+\d+\s*@\s*[\d:]+)/i',
            '/Bidding Start Time[:\s]+(\w+\s+\d+\s+\w+\s+\d+\s*@\s*[\d:]+)/i',
            '/Start Time[:\s]+(\w+\s+\d+\s+\w+\s+\d+\s*@\s*[\d:]+)/i',
            '/starts?\s+(\w+\s+\d+,?\s+\d+\s+[\d:]+)/i',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $matches)) {
                $result = self::parse($matches[1]);
                if ($result) {
                    return $result;
                }
            }
        }
        
        return null;
    }

    /**
     * Parse separate date and time elements
     */
    public static function combineDateTime(?string $date, ?string $time): ?DateTime {
        if (!$date) {
            return null;
        }
        
        // Clean date: "Mon, 16 Mar 2026" -> "16 Mar 2026"
        $date = preg_replace('/^[A-Za-z]+,\s*/', '', $date);
        
        if ($time) {
            $date .= ' ' . $time;
        }
        
        return self::parse($date);
    }
}
