<?php

require_once __DIR__ . '/BaseScraper.php';
require_once __DIR__ . '/GoBidScraper.php';
require_once __DIR__ . '/AucorScraper.php';
require_once __DIR__ . '/AuctionOperationScraper.php';
require_once __DIR__ . '/BiddersChoiceScraper.php';
require_once __DIR__ . '/ClaremartScraper.php';
require_once __DIR__ . '/HighStreetScraper.php';
require_once __DIR__ . '/SAAuctionGroupScraper.php';
require_once __DIR__ . '/WHAuctioneersScraper.php';
require_once __DIR__ . '/CahiScraper.php';
require_once __DIR__ . '/NucoScraper.php';
require_once __DIR__ . '/WCTAuctionsScraper.php';
require_once __DIR__ . '/AuctionIncScraper.php';

/**
 * Scraper Manager
 * 
 * Orchestrates all scrapers, handles scheduling, and stores results
 */
class ScraperManager {
    
    private array $scrapers = [];
    private ?PDO $database = null;
    private array $results = [];
    
    public function __construct(?PDO $database = null) {
        $this->database = $database;
        $this->registerDefaultScrapers();
    }
    
    /**
     * Register the default scrapers
     */
    private function registerDefaultScrapers(): void {
        $this->scrapers = [
            new GoBidScraper(),
            new AucorScraper(),
            new AuctionOperationScraper(),
            new BiddersChoiceScraper(),
            new ClaremartScraper(),
            new HighStreetScraper(),
            new SAAuctionGroupScraper(),
            new WHAuctioneersScraper(),
            new CahiScraper(),
            new NucoScraper(),
            new WCTAuctionsScraper(),
            new AuctionIncScraper(),
        ];
    }
    
    /**
     * Add a custom scraper
     */
    public function addScraper(BaseScraper $scraper): self {
        $this->scrapers[] = $scraper;
        return $this;
    }
    
    /**
     * Run all scrapers
     * 
     * @return array Results from all scrapers
     */
    public function runAll(): array {
        $this->results = [
            'timestamp' => date('Y-m-d H:i:s'),
            'scrapers' => [],
            'total_auctions' => 0,
            'errors' => [],
        ];
        
        foreach ($this->scrapers as $scraper) {
            $sourceName = $scraper->getSourceName();
            
            try {
                $startTime = microtime(true);
                
                $auctions = $scraper->scrape();
                
                $duration = round(microtime(true) - $startTime, 2);
                
                $this->results['scrapers'][$sourceName] = [
                    'status' => 'success',
                    'auctions_found' => count($auctions),
                    'duration_seconds' => $duration,
                    'auctions' => $auctions,
                ];
                
                $this->results['total_auctions'] += count($auctions);
                
                // Store in database if available
                if ($this->database && !empty($auctions)) {
                    $this->storeAuctions($sourceName, $auctions);
                }
                
            } catch (Exception $e) {
                $this->results['scrapers'][$sourceName] = [
                    'status' => 'error',
                    'error' => $e->getMessage(),
                    'auctions_found' => 0,
                ];
                
                $this->results['errors'][] = [
                    'source' => $sourceName,
                    'error' => $e->getMessage(),
                ];
            }
            
            // Brief delay between scrapers
            sleep(1);
        }
        
        return $this->results;
    }
    
    /**
     * Run a specific scraper by name
     */
    public function runScraper(string $sourceName): ?array {
        foreach ($this->scrapers as $scraper) {
            if ($scraper->getSourceName() === $sourceName) {
                try {
                    $auctions = $scraper->scrape();
                    
                    if ($this->database && !empty($auctions)) {
                        $this->storeAuctions($sourceName, $auctions);
                    }
                    
                    return [
                        'status' => 'success',
                        'source' => $sourceName,
                        'auctions_found' => count($auctions),
                        'auctions' => $auctions,
                    ];
                } catch (Exception $e) {
                    return [
                        'status' => 'error',
                        'source' => $sourceName,
                        'error' => $e->getMessage(),
                    ];
                }
            }
        }
        
        return null;
    }
    
    /**
     * Get all registered scrapers
     */
    public function getScrapers(): array {
        return $this->scrapers;
    }
    
    /**
     * Store auctions in database
     */
    private function storeAuctions(string $sourceName, array $auctions): void {
        if (!$this->database) {
            return;
        }
        
        $stmt = $this->database->prepare("
            INSERT INTO calendar_events 
            (external_id, title, event_date, location, source_name, source_url, scraped_at)
            VALUES (:external_id, :title, :event_date, :location, :source_name, :source_url, :scraped_at)
            ON DUPLICATE KEY UPDATE
            title = VALUES(title),
            event_date = VALUES(event_date),
            location = VALUES(location),
            source_url = VALUES(source_url),
            scraped_at = VALUES(scraped_at)
        ");
        
        foreach ($auctions as $auction) {
            $data = $auction->toArray();
            
            $stmt->execute([
                ':external_id' => $data['external_id'],
                ':title' => $data['title'],
                ':event_date' => $data['event_date'],
                ':location' => $data['location'],
                ':source_name' => $data['source_name'],
                ':source_url' => $data['source_url'],
                ':scraped_at' => $data['scraped_at'],
            ]);
        }
    }
    
    /**
     * Get results from last run
     */
    public function getResults(): array {
        return $this->results;
    }
    
    /**
     * Clean up old events (auctions that have passed)
     * 
     * @param int $daysOld Number of days after event to keep
     */
    public function cleanupOldEvents(int $daysOld = 7): int {
        if (!$this->database) {
            return 0;
        }
        
        $stmt = $this->database->prepare("
            DELETE FROM calendar_events 
            WHERE event_date < DATE_SUB(NOW(), INTERVAL :days DAY)
        ");
        
        $stmt->execute([':days' => $daysOld]);
        
        return $stmt->rowCount();
    }
}
