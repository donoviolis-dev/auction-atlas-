<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * Nuco Auctioneers Scraper
 * 
 * Scrapes upcoming auctions from https://bidding.nucoauctioneers.com/Auctions
 */
class NucoScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://bidding.nucoauctioneers.com';
        $this->sourceName = 'Nuco Auctioneers';
    }
    
    public function getSourceName(): string {
        return 'Nuco Auctioneers';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/Auctions';
    }
    
    protected function getItemSelector(): string {
        return '.auction-heading-container, .auction-item, .col-xs-12';
    }
    
    /**
     * Extract title from Nuco auction element
     */
    protected function extractTitle($el): ?string {
        // Try auction-heading
        $title = $el->find('.auction-heading', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try h2
        $title = $el->find('h2', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try link title
        $link = $el->find('a', 0);
        if ($link && isset($link->title)) {
            return $this->cleanText($link->title);
        }
        
        return null;
    }
    
    /**
     * Extract date from Nuco auction element
     * 
     * Format: "Starts: 24 Mar 08:00 | Ends: 26 Mar 10:30"
     */
    protected function extractDate($el): ?DateTime {
        // Get all text
        $text = $el->text();
        
        // Try to extract end date first (more important)
        if (preg_match('/Ends:\s*(\d+\s+\w+\s+\d+[\d:]*)/i', $text, $matches)) {
            return DateParser::parse($matches[1]);
        }
        
        // Try start date
        if (preg_match('/Starts:\s*(\d+\s+\w+\s+\d+[\d:]*)/i', $text, $matches)) {
            return DateParser::parse($matches[1]);
        }
        
        // Try span format
        $dateSpan = $el->find('.item-info strong span', 0)?->text();
        if ($dateSpan) {
            if (preg_match('/Ends:\s*(\d+\s+\w+\s+\d+)/i', $dateSpan, $matches)) {
                return DateParser::parse($matches[1]);
            }
            if (preg_match('/Starts:\s*(\d+\s+\w+\s+\d+)/i', $dateSpan, $matches)) {
                return DateParser::parse($matches[1]);
            }
        }
        
        return null;
    }
    
    /**
     * Extract location from Nuco auction element
     */
    protected function extractLocation($el): ?string {
        // Try description
        $desc = $el->find('.auction-description-padding, .auction-description', 0)?->text();
        
        if ($desc) {
            // Look for address patterns
            if (preg_match('/Address[:\s]+([^.|]+)/i', $desc, $matches)) {
                return trim($matches[1]);
            }
            
            // Look for venue
            if (preg_match('/Venue[:\s]+([^.|]+)/i', $desc, $matches)) {
                return trim($matches[1]);
            }
            
            // Look for location indicators
            if (preg_match('/(Gauteng|KwaZulu-Natal|Western Cape|Eastern Cape|Mpumalanga|Limpopo|North West|Free State|Northern Cape)/i', $desc, $matches)) {
                return $matches[1];
            }
        }
        
        // Try tags
        $tags = $el->find('.auction-tag');
        foreach ($tags as $tag) {
            $tagText = $tag->text();
            // Check for province indicators
            if (preg_match('/(GP|KZN|WC|EC|MP|LP|NC|NW|FS)/i', $tagText, $matches)) {
                return $matches[1];
            }
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/Auctions/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
