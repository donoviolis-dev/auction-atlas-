<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * AuctionInc Scraper
 * 
 * Scrapes upcoming auctions from https://www.auctioninc.co.za/auctions/auctions.aspx
 */
class AuctionIncScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://www.auctioninc.co.za';
        $this->sourceName = 'AuctionInc';
    }
    
    public function getSourceName(): string {
        return 'AuctionInc';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/auctions/auctions.aspx';
    }
    
    protected function getItemSelector(): string {
        return '.copy.info, .auction-item, .col-md-8';
    }
    
    /**
     * Extract title from AuctionInc auction element
     */
    protected function extractTitle($el): ?string {
        // Try for property title in b tag
        $title = $el->find('b', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try p tag with bold
        $title = $el->find('p b', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try heading
        $title = $el->find('h2, h3, h4', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from AuctionInc auction element
     * 
     * Format: "AUCTION DATE: 21-03-2026" and "AUCTION START TIME: 10:30"
     */
    protected function extractDate($el): ?DateTime {
        // Try to find auction date
        $text = $el->text();
        
        // Pattern: "AUCTION DATE" followed by date
        if (preg_match('/AUCTION DATE[:\s]*<br[^>]*>\s*<b[^>]*>\s*(\d+[-\/]\d+[-\/]\d+)/i', $text, $matches)) {
            $dateStr = $matches[1];
            
            // Try to find time too
            if (preg_match('/AUCTION START TIME[:\s]*<br[^>]*>\s*<b[^>]*>\s*(\d+:\d+)/i', $text, $timeMatches)) {
                $dateStr .= ' ' . $timeMatches[1];
            }
            
            return DateParser::parse($dateStr);
        }
        
        // Try simpler pattern
        if (preg_match('/(\d{2}-\d{2}-\d{4})/', $text, $matches)) {
            return DateParser::parse($matches[1]);
        }
        
        return null;
    }
    
    /**
     * Extract location from AuctionInc auction element
     */
    protected function extractLocation($el): ?string {
        // Try to find address in .sml p
        $address = $el->find('.sml p', 0)?->text();
        
        if ($address) {
            // Extract location from address like "2 Gresham Road , Robertsham Ext 1 - Property Ref: f108687, Johannesburg , Gauteng"
            if (preg_match('/([A-Za-z\s]+),\s*(Gauteng|KwaZulu-Natal|Western\s+Cape|Eastern\s+Cape|Mpumalanga|Limpopo|North\s+West|Free\s+State|Northern\s+Cape)/i', $address, $matches)) {
                return trim($matches[0]);
            }
            
            // Try to find city
            if (preg_match('/(Johannesburg|Cape\s+Town|Durban|Pretoria|Port\s+Elizabeth|Bloemfontein)/i', $address, $matches)) {
                return $matches[1];
            }
        }
        
        // Try second sml p
        $address = $el->find('.sml p', 1)?->text();
        if ($address) {
            if (preg_match('/([A-Za-z\s]+),\s*(Gauteng|KwaZulu-Natal|Western\s+Cape|Eastern\s+Cape|Mpumalanga|Limpopo|North\s+West|Free\s+State|Northern\s+Cape)/i', $address, $matches)) {
                return trim($matches[0]);
            }
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/auctions/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
