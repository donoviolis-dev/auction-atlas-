<?php

/**
 * Base Calendar Auction Data Transfer Object
 * 
 * Represents the minimum required data for calendar display
 */
class CalendarAuction {
    private ?int $id = null;
    private string $title;
    private DateTime $eventDate;
    private string $location;
    private string $sourceName;
    private string $sourceUrl;
    private ?DateTime $scrapedAt = null;
    private ?string $externalId = null;

    public function __construct(
        string $title,
        DateTime $eventDate,
        string $location = 'Unconfirmed',
        string $sourceName = '',
        string $sourceUrl = ''
    ) {
        $this->title = $title;
        $this->eventDate = $eventDate;
        $this->location = $location;
        $this->sourceName = $sourceName;
        $this->sourceUrl = $sourceUrl;
        $this->scrapedAt = new DateTime();
    }

    // Getters
    public function getId(): ?int {
        return $this->id;
    }

    public function getTitle(): string {
        return $this->title;
    }

    public function getEventDate(): DateTime {
        return $this->eventDate;
    }

    public function getLocation(): string {
        return $this->location;
    }

    public function getSourceName(): string {
        return $this->sourceName;
    }

    public function getSourceUrl(): string {
        return $this->sourceUrl;
    }

    public function getScrapedAt(): ?DateTime {
        return $this->scrapedAt;
    }

    public function getExternalId(): ?string {
        return $this->externalId;
    }

    // Setters
    public function setId(int $id): self {
        $this->id = $id;
        return $this;
    }

    public function setTitle(string $title): self {
        $this->title = $title;
        return $this;
    }

    public function setEventDate(DateTime $eventDate): self {
        $this->eventDate = $eventDate;
        return $this;
    }

    public function setLocation(string $location): self {
        $this->location = $location;
        return $this;
    }

    public function setSourceName(string $sourceName): self {
        $this->sourceName = $sourceName;
        return $this;
    }

    public function setSourceUrl(string $sourceUrl): self {
        $this->sourceUrl = $sourceUrl;
        return $this;
    }

    public function setExternalId(string $externalId): self {
        $this->externalId = $externalId;
        return $this;
    }

    /**
     * Convert to array for database storage
     */
    public function toArray(): array {
        return [
            'title' => $this->title,
            'event_date' => $this->eventDate->format('Y-m-d H:i:s'),
            'location' => $this->location,
            'source_name' => $this->sourceName,
            'source_url' => $this->sourceUrl,
            'external_id' => $this->externalId,
            'scraped_at' => $this->scrapedAt?->format('Y-m-d H:i:s') ?? date('Y-m-d H:i:s')
        ];
    }

    /**
     * Convert to FullCalendar event format
     */
    public function toCalendarEvent(): array {
        return [
            'id' => $this->id ?? $this->externalId ?? uniqid(),
            'title' => $this->title,
            'start' => $this->eventDate->format('Y-m-d\TH:i:s'),
            'location' => $this->location,
            'source' => $this->sourceName,
            'url' => $this->sourceUrl ?: '/auctions'
        ];
    }

    /**
     * Create from database row
     */
    public static function fromDatabase(array $row): self {
        $auction = new self(
            $row['title'],
            new DateTime($row['event_date']),
            $row['location'] ?? 'Unconfirmed',
            $row['source_name'] ?? '',
            $row['source_url'] ?? ''
        );
        
        if (isset($row['id'])) {
            $auction->setId((int)$row['id']);
        }
        
        if (isset($row['external_id'])) {
            $auction->setExternalId($row['external_id']);
        }
        
        return $auction;
    }
}
