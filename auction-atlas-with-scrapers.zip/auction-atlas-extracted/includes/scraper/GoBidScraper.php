<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * GoBid Scraper
 * 
 * Scrapes upcoming auctions from https://www.gobid.co.za/live
 */
class GoBidScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://www.gobid.co.za';
        $this->sourceName = 'GoBid';
    }
    
    public function getSourceName(): string {
        return 'GoBid';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/live';
    }
    
    protected function getItemSelector(): string {
        return '.gb_online_auction_block';
    }
    
    /**
     * Extract title from GoBid auction element
     * 
     * GoBid doesn't show title in the list - we derive it from date/lots
     */
    protected function extractTitle($el): ?string {
        // Try to get the catalogue ID from links
        $catalogueLink = $el->find('a[href*="/live/catalogue/"]', 0);
        
        if ($catalogueLink) {
            $href = $catalogueLink->href;
            if (preg_match('/catalogue\/([A-Z0-9]+)/i', $href, $matches)) {
                $catalogueId = $matches[1];
                
                // Get lot count
                $lotCount = $el->find('.lot_value', 0)?->text() ?? 'Multiple';
                
                // Get location
                $location = $el->find('.locations .location_value', 0)?->text() ?? '';
                
                return "GoBid Auction - {$catalogueId} ({$lotCount} lots) - {$location}";
            }
        }
        
        // Fallback: use date and location
        $dateText = $el->find('.date', 0)?->text() ?? '';
        $timeText = $el->find('.time', 0)?->text() ?? '';
        $location = $el->find('.locations .location_value', 0)?->text() ?? 'National';
        
        if ($dateText) {
            return "GoBid Auction - {$dateText} {$timeText} - {$location}";
        }
        
        return null;
    }
    
    /**
     * Extract date from GoBid auction element
     */
    protected function extractDate($el): ?DateTime {
        $dateText = $el->find('.date', 0)?->text();
        $timeText = $el->find('.time', 0)?->text();
        
        if (!$dateText) {
            return null;
        }
        
        // Clean date: "Mon, 16 Mar 2026" -> "16 Mar 2026"
        $dateText = preg_replace('/^[A-Za-z]+,\s*/', '', $dateText);
        
        // Combine with time if available
        if ($timeText) {
            $dateText .= ' ' . $timeText;
        }
        
        return DateParser::parse($dateText);
    }
    
    /**
     * Extract location from GoBid auction element
     */
    protected function extractLocation($el): ?string {
        $location = $el->find('.locations .location_value', 0)?->text();
        
        if ($location) {
            return trim($location);
        }
        
        // Also check for venue info
        $venue = $el->find('.venue', 0)?->text();
        if ($venue) {
            return trim($venue);
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL (link to catalogue or auction page)
     */
    protected function getSourceUrl($el): string {
        // Try catalogue link first
        $catalogueLink = $el->find('a[href*="/live/catalogue/"]', 0);
        if ($catalogueLink && isset($catalogueLink->href)) {
            return $this->baseUrl . $catalogueLink->href;
        }
        
        // Try auction link
        $auctionLink = $el->find('a[href*="/live/"]', 0);
        if ($auctionLink && isset($auctionLink->href)) {
            return $this->baseUrl . $auctionLink->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
