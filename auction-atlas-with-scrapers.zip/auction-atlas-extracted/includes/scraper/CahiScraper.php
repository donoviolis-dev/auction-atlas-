<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * Cahi Auctioneers Scraper
 * 
 * Scrapes upcoming auctions from https://www.cahi.co.za/movable-vehicle-auctions
 * and https://cahi.co.za/property-auction/
 */
class CahiScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://www.cahi.co.za';
        $this->sourceName = 'Cahi Auctioneers';
    }
    
    public function getSourceName(): string {
        return 'Cahi Auctioneers';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/movable-vehicle-auctions';
    }
    
    protected function getItemSelector(): string {
        return '.bde-text-1341-121, .bde-icon-list, .auction-item, .event-item';
    }
    
    /**
     * Extract title from Cahi auction element
     */
    protected function extractTitle($el): ?string {
        // Try bde-text
        $title = $el->find('.bde-text-1341-121', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try h2
        $title = $el->find('h2', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try h3
        $title = $el->find('h3', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from Cahi auction element
     * 
     * Format: "17 & 18 March 2026"
     */
    protected function extractDate($el): ?DateTime {
        // Try icon-list text
        $dateText = $el->find('.bde-icon-list__text', 0)?->text();
        
        if ($dateText) {
            // Format: "17 & 18 March 2026" - take the first date
            $dateText = preg_replace('/\s*&\s*\d+\s+/', ' ', $dateText);
            return DateParser::parse($dateText);
        }
        
        // Try all text content
        $text = $el->text();
        
        // Look for date patterns like "17 March 2026" or "17 & 18 March 2026"
        if (preg_match('/(\d+\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4})/i', $text, $matches)) {
            return DateParser::parse($matches[1]);
        }
        
        return null;
    }
    
    /**
     * Extract location from Cahi auction element
     */
    protected function extractLocation($el): ?string {
        // Try icon list for location
        $locationIcon = $el->find('.bde-icon-list__icon', 0);
        
        if ($locationIcon) {
            // Check if it's a location icon
            $iconHtml = $locationIcon->innertext();
            if (stripos($iconHtml, 'map-marker') !== false || stripos($iconHtml, 'location') !== false) {
                $location = $el->find('.bde-icon-list__text', 1)?->text();
                if ($location) {
                    return $this->cleanText($location);
                }
            }
        }
        
        // Try full text for location patterns
        $text = $el->text();
        
        if (preg_match('/Location[:\s]+([A-Za-z\s]+)/i', $text, $matches)) {
            return trim($matches[1]);
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/auction/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
