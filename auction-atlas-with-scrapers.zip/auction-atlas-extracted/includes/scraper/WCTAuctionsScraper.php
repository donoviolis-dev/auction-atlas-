<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * WCT Auctions Scraper
 * 
 * Scrapes upcoming auctions from https://online.wctauctions.co.za/
 * Uses same platform as Aucor/Auction Operation (AngularJS)
 */
class WCTAuctionsScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://online.wctauctions.co.za';
        $this->sourceName = 'WCT Auctions';
    }
    
    public function getSourceName(): string {
        return 'WCT Auctions';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/auctions';
    }
    
    protected function getItemSelector(): string {
        return '.auction-row-header, div[ng-repeat*="auction"]';
    }
    
    /**
     * Extract title from WCT auction element
     */
    protected function extractTitle($el): ?string {
        // Title is in .title element
        $title = $el->find('.title', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try alternative selectors
        $title = $el->find('.auction-title', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from WCT auction element
     * 
     * Date format: "Starts: Mar 23, 2026 at 12 PM SAST • Closing Mar 25, 2026 at 9:30 AM SAST • Pretoria"
     */
    protected function extractDate($el): ?DateTime {
        $subtitle = $el->find('.subtitle', 0)?->text();
        
        if (!$subtitle) {
            return null;
        }
        
        // Try to extract closing date first
        $date = DateParser::extractClosingDate($subtitle);
        if ($date) {
            return $date;
        }
        
        // Try start date
        $date = DateParser::extractStartDate($subtitle);
        if ($date) {
            return $date;
        }
        
        return null;
    }
    
    /**
     * Extract location from WCT auction element
     */
    protected function extractLocation($el): ?string {
        $subtitle = $el->find('.subtitle', 0)?->text();
        
        if (!$subtitle) {
            return 'Unconfirmed';
        }
        
        // Pattern: "Starts: Mar 23, 2026 at 12 PM SAST • Closing Mar 25, 2026 at 9:30 AM SAST • Pretoria"
        // Extract venue after the last •
        if (preg_match('/•\s*([A-Za-z\s]+)\s*$/', $subtitle, $matches)) {
            $location = trim($matches[1]);
            // Remove timer element if present
            $location = preg_replace('/\s*\d+H\s*\d+M.*$/i', '', $location);
            
            if (!empty($location)) {
                return $this->cleanText($location);
            }
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/auctions/"]', 0);
        
        if ($link && isset($link->href)) {
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
