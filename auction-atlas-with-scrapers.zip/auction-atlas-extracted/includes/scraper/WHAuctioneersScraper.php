<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * WH Auctioneers Scraper
 * 
 * Scrapes upcoming auctions from https://www.whauctions.com
 * Uses their API if available, otherwise falls back to HTML parsing
 */
class WHAuctioneersScraper extends BaseScraper {
    
    // API credentials (provided by user)
    private string $appId = 'XT8JSVUGX7';
    private string $apiKey = 'a759ae2e577c4163b4df92fbfbe1dbac';
    private string $apiBaseUrl = 'https://api.whauctions.com/v1';
    
    public function __construct() {
        $this->baseUrl = 'https://www.whauctions.com';
        $this->sourceName = 'WH Auctioneers';
    }
    
    public function getSourceName(): string {
        return 'WH Auctioneers';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl;
    }
    
    /**
     * Try API first, fall back to HTML parsing
     */
    public function scrape(): array {
        // Try API first
        $auctions = $this->scrapeViaApi();
        
        // If API fails or returns nothing, fall back to HTML
        if (empty($auctions)) {
            $auctions = $this->scrapeViaHtml();
        }
        
        return $auctions;
    }
    
    /**
     * Scrape via API
     */
    private function scrapeViaApi(): array {
        $url = $this->apiBaseUrl . '/auctions?status=upcoming';
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => [
                'X-App-Id: ' . $this->appId,
                'X-Api-Key: ' . $this->apiKey,
                'Content-Type: application/json',
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200 || empty($response)) {
            return [];
        }
        
        $data = json_decode($response, true);
        
        if (!isset($data['auctions']) || empty($data['auctions'])) {
            return [];
        }
        
        $auctions = [];
        
        foreach ($data['auctions'] as $item) {
            $title = $item['title'] ?? $item['name'] ?? null;
            $dateStr = $item['end_date'] ?? $item['auction_date'] ?? null;
            
            if ($title && $dateStr) {
                $eventDate = DateParser::parse($dateStr);
                
                if ($eventDate) {
                    $auction = new CalendarAuction(
                        $title,
                        $eventDate,
                        $item['location'] ?? $item['venue'] ?? 'Unconfirmed',
                        $this->getSourceName(),
                        $item['url'] ?? $item['link'] ?? $this->getAuctionPageUrl()
                    );
                    
                    $auction->setExternalId($this->getSourceName() . '_' . ($item['id'] ?? uniqid()));
                    $auctions[] = $auction;
                }
            }
        }
        
        return $auctions;
    }
    
    /**
     * Scrape via HTML parsing (fallback)
     */
    private function scrapeViaHtml(): array {
        $html = $this->fetchPage($this->getAuctionPageUrl());
        
        if (!$html) {
            return [];
        }
        
        $dom = $this->parseHtml($html);
        $elements = $dom->find('.upcoming-auctions-item__content, .auction-item');
        
        $auctions = [];
        
        foreach ($elements as $el) {
            $title = $this->extractTitle($el);
            $date = $this->extractDate($el);
            
            if ($title && $date) {
                $auction = new CalendarAuction(
                    $title,
                    $date,
                    $this->extractLocation($el) ?? 'Unconfirmed',
                    $this->getSourceName(),
                    $this->getSourceUrl($el)
                );
                
                $externalId = $this->generateExternalId($title, $date);
                $auction->setExternalId($externalId);
                
                $auctions[] = $auction;
            }
        }
        
        return $auctions;
    }
    
    protected function getItemSelector(): string {
        return '.upcoming-auctions-item__content, .auction-item';
    }
    
    /**
     * Extract title from WH Auctioneers element
     */
    protected function extractTitle($el): ?string {
        $title = $el->find('.upcoming-auctions-item__title', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        $title = $el->find('h2', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        $title = $el->find('h3', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from WH Auctioneers element
     * 
     * Format: "Closes: 18 Mar 2026, 10:30 GMT+2" or "Started"
     */
    protected function extractDate($el): ?DateTime {
        // Try end-time first
        $dateText = $el->find('.upcoming-auctions-item__end-time', 0)?->text();
        
        if ($dateText) {
            // Extract from "Closes: 18 Mar 2026, 10:30 GMT+2"
            if (preg_match('/Closes:\s*(\d+\s+\w+\s+\d+[\d:,]*\s*(?:GMT\+?\d+)?)/i', $dateText, $matches)) {
                return DateParser::parse($matches[1]);
            }
        }
        
        // Try start-time
        $dateText = $el->find('.upcoming-auctions-item__start-time', 0)?->text();
        if ($dateText && strpos($dateText, 'Started') !== false) {
            // Auction has started - get the end time
            $dateText = $el->find('.upcoming-auctions-item__end-time', 0)?->text();
            if ($dateText) {
                if (preg_match('/(\d+\s+\w+\s+\d+[\d:,]*)/i', $dateText, $matches)) {
                    return DateParser::parse($matches[1]);
                }
            }
        }
        
        return null;
    }
    
    /**
     * Extract location from WH Auctioneers element
     */
    protected function extractLocation($el): ?string {
        $location = $el->find('.upcoming-auctions-item__location', 0)?->text();
        
        if ($location) {
            return $this->cleanText($location);
        }
        
        // Try description for location
        $desc = $el->find('.upcoming-auctions-item__description', 0)?->text();
        if ($desc) {
            if (preg_match('/Address[:\s]+([^.]+)/i', $desc, $matches)) {
                return trim($matches[1]);
            }
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/auctions/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
