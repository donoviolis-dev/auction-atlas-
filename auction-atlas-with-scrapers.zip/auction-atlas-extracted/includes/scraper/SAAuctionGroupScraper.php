<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * SA Auction Group Scraper
 * 
 * Scrapes upcoming auctions from https://www.saauctiongroup.co.za/auctions
 */
class SAAuctionGroupScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://www.saauctiongroup.co.za';
        $this->sourceName = 'SA Auction Group';
    }
    
    public function getSourceName(): string {
        return 'SA Auction Group';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/auctions';
    }
    
    protected function getItemSelector(): string {
        return '.auction, .auction-listing .auction, div[class*="auction"]';
    }
    
    /**
     * Extract title from SA Auction Group auction element
     */
    protected function extractTitle($el): ?string {
        // Try auction-heading first
        $title = $el->find('.auction-heading', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try h2
        $title = $el->find('h2', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try link title attribute
        $link = $el->find('a', 0);
        if ($link && isset($link->title)) {
            return $this->cleanText($link->title);
        }
        
        return null;
    }
    
    /**
     * Extract date from SA Auction Group auction element
     * 
     * Format: "Starts: 02 Mar 2026 | Ends: 17 Mar 2026"
     */
    protected function extractDate($el): ?DateTime {
        // Try item-info first
        $itemInfo = $el->find('.item-info', 0)?->text();
        
        if ($itemInfo) {
            // Try to extract end date (more important)
            if (preg_match('/Ends:\s*(\d+\s+\w+\s+\d+)/i', $itemInfo, $matches)) {
                $date = DateParser::parse($matches[1]);
                if ($date) {
                    return $date;
                }
            }
            
            // Try start date
            if (preg_match('/Starts:\s*(\d+\s+\w+\s+\d+)/i', $itemInfo, $matches)) {
                return DateParser::parse($matches[1]);
            }
        }
        
        // Try direct span
        $dateText = $el->find('.item-info span', 0)?->text();
        if ($dateText) {
            // Extract date from "Starts: 02 Mar 2026 | Ends: 17 Mar 2026"
            if (preg_match('/Ends:\s*(\d+\s+\w+\s+\d+)/i', $dateText, $matches)) {
                return DateParser::parse($matches[1]);
            }
            if (preg_match('/Starts:\s*(\d+\s+\w+\s+\d+)/i', $dateText, $matches)) {
                return DateParser::parse($matches[1]);
            }
        }
        
        return null;
    }
    
    /**
     * Extract location from SA Auction Group auction element
     */
    protected function extractLocation($el): ?string {
        // Try description
        $desc = $el->find('.auction-description', 0)?->text();
        
        if ($desc) {
            // Look for location patterns
            if (preg_match('/Location[:\s]+([^|<]+)/i', $desc, $matches)) {
                return trim($matches[1]);
            }
            
            // Look for venue references
            if (preg_match('/Venue[:\s]+([^|<]+)/i', $desc, $matches)) {
                return trim($matches[1]);
            }
            
            // Look for address patterns
            if (preg_match('/(\d+\s+\w+\s+(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr)[^,|]+)/i', $desc, $matches)) {
                return trim($matches[1]);
            }
        }
        
        // Try tags for location hints
        $tags = $el->find('.auction-tag');
        foreach ($tags as $tag) {
            $tagText = $tag->text();
            // Check for province indicators
            if (preg_match('/(GP|KZN|WC|EC|MP|LP|NC|NW|FS)/i', $tagText, $matches)) {
                return $matches[1]; // Return province code
            }
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL
     */
    protected function getSourceUrl($el): string {
        $link = $el->find('a[href*="/Auctions/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
