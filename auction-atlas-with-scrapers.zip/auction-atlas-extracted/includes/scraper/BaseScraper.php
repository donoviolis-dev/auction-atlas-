<?php

require_once __DIR__ . '/autoload.php';
require_once __DIR__ . '/CalendarAuction.php';
require_once __DIR__ . '/DateParser.php';

/**
 * Base Scraper Class
 * 
 * Abstract base class for all auction site scrapers.
 * Provides common functionality for HTTP fetching, parsing, and data extraction.
 */
abstract class BaseScraper {
    
    protected string $baseUrl;
    protected string $sourceName;
    protected int $timeout = 30;
    protected int $delayBetweenRequests = 2; // seconds
    protected array $userAgents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
    ];
    
    // Rate limiting
    private static array $lastRequestTime = [];
    
    /**
     * Get the name of the auction source
     */
    abstract public function getSourceName(): string;
    
    /**
     * Get the main URL to scrape
     */
    abstract public function getAuctionPageUrl(): string;
    
    /**
     * Get the CSS selector for auction items
     */
    abstract protected function getItemSelector(): string;
    
    /**
     * Extract title from an auction element
     */
    abstract protected function extractTitle($element): ?string;
    
    /**
     * Extract date from an auction element
     */
    abstract protected function extractDate($element): ?DateTime;
    
    /**
     * Extract location from an auction element
     */
    abstract protected function extractLocation($element): ?string;
    
    /**
     * Run the scraper and return all auctions
     * 
     * @return CalendarAuction[]
     */
    public function scrape(): array {
        $html = $this->fetchPage($this->getAuctionPageUrl());
        
        if (!$html) {
            return [];
        }
        
        $dom = $this->parseHtml($html);
        $elements = $dom->find($this->getItemSelector());
        
        $auctions = [];
        
        foreach ($elements as $el) {
            $title = $this->extractTitle($el);
            $date = $this->extractDate($el);
            
            // Only include if we have the minimum required data
            if ($title && $date) {
                $auction = new CalendarAuction(
                    $title,
                    $date,
                    $this->extractLocation($el) ?? 'Unconfirmed',
                    $this->getSourceName(),
                    $this->getSourceUrl($el)
                );
                
                // Generate external ID from source + title + date
                $externalId = $this->generateExternalId($title, $date);
                $auction->setExternalId($externalId);
                
                $auctions[] = $auction;
            }
        }
        
        return $auctions;
    }
    
    /**
     * Fetch a page with rate limiting
     */
    protected function fetchPage(string $url): ?string {
        // Apply rate limiting
        $this->applyRateLimit();
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_USERAGENT => $this->getRandomUserAgent(),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language: en-ZA,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'Cache-Control: no-cache',
                'Pragma: no-cache',
            ],
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($response === false || !empty($error)) {
            error_log("Scraper error for {$this->getSourceName()}: " . $error);
            return null;
        }
        
        if ($httpCode === 429) {
            // Rate limited - wait longer and retry
            sleep(10);
            return $this->fetchPage($url);
        }
        
        if ($httpCode !== 200) {
            error_log("Scraper HTTP error for {$this->getSourceName()}: HTTP {$httpCode}");
            return null;
        }
        
        return $response;
    }
    
    /**
     * Parse HTML string into a DOMDocument
     */
    protected function parseHtml(string $html): \simple_html_dom {
        // Using simple_html_dom library
        return str_get_html($html);
    }
    
    /**
     * Get a random user agent
     */
    protected function getRandomUserAgent(): string {
        return $this->userAgents[array_rand($this->userAgents)];
    }
    
    /**
     * Apply rate limiting between requests
     */
    protected function applyRateLimit(): void {
        $domain = parse_url($this->getAuctionPageUrl(), PHP_URL_HOST);
        
        if (isset(self::$lastRequestTime[$domain])) {
            $elapsed = time() - self::$lastRequestTime[$domain];
            if ($elapsed < $this->delayBetweenRequests) {
                sleep($this->delayBetweenRequests - $elapsed);
            }
        }
        
        self::$lastRequestTime[$domain] = time();
    }
    
    /**
     * Generate a unique external ID for deduplication
     */
    protected function generateExternalId(string $title, DateTime $date): string {
        $slug = strtolower(trim($title));
        $slug = preg_replace('/[^a-z0-9\s]/', '', $slug);
        $slug = substr($slug, 0, 50);
        
        return $this->getSourceName() . '_' . $slug . '_' . $date->format('Ymd');
    }
    
    /**
     * Get source URL for an element (can be overridden)
     */
    protected function getSourceUrl($element): string {
        return $this->getAuctionPageUrl();
    }
    
    /**
     * Clean and normalize text
     */
    protected function cleanText(?string $text): string {
        if ($text === null) {
            return '';
        }
        
        // Remove extra whitespace
        $text = preg_replace('/\s+/', ' ', $text);
        
        return trim($text);
    }
    
    /**
     * Find element using multiple possible selectors
     */
    protected function findFirst($element, array $selectors): ?\simple_html_dom_node {
        foreach ($selectors as $selector) {
            $result = $element->find($selector, 0);
            if ($result) {
                return $result;
            }
        }
        return null;
    }
}
