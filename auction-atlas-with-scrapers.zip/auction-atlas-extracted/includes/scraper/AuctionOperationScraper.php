<?php

require_once __DIR__ . '/AucorScraper.php';

/**
 * Auction Operation Scraper
 * 
 * Uses the same platform as Aucor - scrapes from https://live.auctionoperation.co.za
 * Inherits from AucorScraper as they share the same HTML structure
 */
class AuctionOperationScraper extends AucorScraper {
    
    public function __construct() {
        // Override base URL for Auction Operation
        $this->baseUrl = 'https://live.auctionoperation.co.za';
        $this->sourceName = 'Auction Operation';
    }
    
    public function getSourceName(): string {
        return 'Auction Operation';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/auctions';
    }
}
