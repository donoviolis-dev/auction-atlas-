<?php

require_once __DIR__ . '/BaseScraper.php';

/**
 * Claremart Auctioneers Scraper
 * 
 * Scrapes upcoming auctions from https://claremart.com/Auctions
 */
class ClaremartScraper extends BaseScraper {
    
    public function __construct() {
        $this->baseUrl = 'https://claremart.com';
        $this->sourceName = 'Claremart Auctioneers';
    }
    
    public function getSourceName(): string {
        return 'Claremart Auctioneers';
    }
    
    public function getAuctionPageUrl(): string {
        return $this->baseUrl . '/Auctions';
    }
    
    protected function getItemSelector(): string {
        return '.thum_one_content, .thumbnail_content, div[id*="ListView"]';
    }
    
    /**
     * Extract title from Claremart auction element
     * 
     * Title format: "Commercial - Retail in Montagu, Montagu"
     */
    protected function extractTitle($el): ?string {
        // Try h5 first
        $title = $el->find('h5', 0)?->text();
        
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try heading with hover_primary class
        $title = $el->find('.hover_primary', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        // Try thum_title
        $title = $el->find('.thum_title', 0)?->text();
        if ($title) {
            return $this->cleanText($title);
        }
        
        return null;
    }
    
    /**
     * Extract date from Claremart auction element
     * 
     * Date format in description: "Bidding Start Time: Wednesday 29 April 2026 @ 09:00"
     * Also: "Bidding End Time: Thursday 30 April 2026 @ 14:30"
     */
    protected function extractDate($el): ?DateTime {
        // Get description text
        $desc = $el->find('.desc-list, .description, .p_10', 0)?->text();
        
        if (!$desc) {
            // Try getting all text
            $desc = $el->text();
        }
        
        // Try end time first (closing date)
        $date = DateParser::extractClosingDate($desc);
        if ($date) {
            return $date;
        }
        
        // Try start time
        $date = DateParser::extractStartDate($desc);
        if ($date) {
            return $date;
        }
        
        return null;
    }
    
    /**
     * Extract location from Claremart auction element
     * 
     * Location format: <i class="fa fa-map-marker"></i>Montagu
     */
    protected function extractLocation($el): ?string {
        // Try map marker icon
        $locationIcon = $el->find('.fa-map-marker', 0);
        
        if ($locationIcon) {
            // Get parent element and extract text
            $parent = $locationIcon->parent();
            if ($parent) {
                $text = $parent->text();
                // Clean up - remove the icon and extra whitespace
                $text = str_replace($locationIcon->text(), '', $text);
                $text = $this->cleanText($text);
                
                if (!empty($text)) {
                    return $text;
                }
            }
        }
        
        // Try p_10 with map marker
        $locationText = $el->find('.p_10 i.fa-map-marker', 0)?->parent()?->text();
        if ($locationText) {
            return $this->cleanText($locationText);
        }
        
        return 'Unconfirmed';
    }
    
    /**
     * Get source URL for Claremart auction
     */
    protected function getSourceUrl($el): string {
        // Try to find detail link
        $link = $el->find('a[href*="/auction/"]', 0);
        
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        // Try details link
        $link = $el->find('a[href*="/Details"]', 0);
        if ($link && isset($link->href)) {
            if (strpos($link->href, 'http') === 0) {
                return $link->href;
            }
            return $this->baseUrl . $link->href;
        }
        
        return $this->getAuctionPageUrl();
    }
}
