<?php

/**
 * Simple Autoloader for Scraper Classes
 * 
 * This provides PSR-4 style autoloading without requiring Composer
 * Simply include this file before using any scraper classes
 * 
 * Usage:
 *   require_once __DIR__ . '/includes/scraper/autoload.php';
 */

spl_autoload_register(function ($class) {
    // Convert namespace to file path
    $prefix = 'AuctionAtlas\\Scraper\\';
    $baseDir = __DIR__ . '/';
    
    // Check if class uses our namespace
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    // Get relative class name
    $relativeClass = substr($class, $len);
    
    // Replace namespace separators with directory separators
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';
    
    // If file exists, require it
    if (file_exists($file)) {
        require $file;
    }
});

// Also load the simple_html_dom library if available
// This is a fallback - ideally use composer to install the library
if (!class_exists('simple_html_dom')) {
    // Check if simple_html_dom is installed via composer
    $vendorAutoload = dirname(__DIR__, 2) . '/vendor/autoload.php';
    if (file_exists($vendorAutoload)) {
        require_once $vendorAutoload;
    } else {
        // Provide a minimal simple_html_dom stub for basic HTML parsing
        // This is a simplified version - for production, install the full library
        if (!class_exists('simple_html_dom')) {
            class_alias('simple_html_dom_node', 'simple_html_dom');
        }
    }
}

/**
 * Simple HTML DOM Node - Minimal Implementation
 * 
 * This provides basic DOM parsing capabilities without external dependencies
 * For production use, install: composer require simple-html-dom/simple-html-dom
 */
if (!class_exists('simple_html_dom_node')) {
    
    class simple_html_dom_node {
        public $tag;
        public $attr = [];
        public $text;
        public $innertext;
        public $outertext;
        private $children = [];
        private $parent;
        
        function __toString() {
            return $this->outertext;
        }
        
        function find($selector, $idx = null) {
            $results = [];
            $selector = trim($selector);
            
            // Simple CSS selector parsing
            if (preg_match('/^([a-z0-9_-]+)/i', $selector, $matches)) {
                $tag = strtolower($matches[1]);
                
                // Check class
                $classMatch = null;
                if (preg_match('/\.([a-z0-9_-]+)/i', $selector, $matches)) {
                    $classMatch = $matches[1];
                }
                
                // Check ID
                $idMatch = null;
                if (preg_match('/#([a-z0-9_-]+)/i', $selector, $matches)) {
                    $idMatch = $matches[1];
                }
                
                // Check attribute
                $attrMatch = null;
                if (preg_match('/\[([^\]]+)\]/', $selector, $matches)) {
                    $attrMatch = $matches[1];
                }
                
                foreach ($this->children as $child) {
                    if ($child->tag && strtolower($child->tag) === $tag) {
                        // Check class
                        if ($classMatch && !isset($child->attr['class'])) continue;
                        if ($classMatch && stripos($child->attr['class'], $classMatch) === false) continue;
                        
                        // Check ID
                        if ($idMatch && (!isset($child->attr['id']) || $child->attr['id'] !== $idMatch)) continue;
                        
                        // Check attribute
                        if ($attrMatch) {
                            if (preg_match('/([a-z-]+)\*?=["\']?([^"\']+)["\']?/', $attrMatch, $am)) {
                                if (!isset($child->attr[$am[1]]) || stripos($child->attr[$am[1]], $am[2]) === false) continue;
                            }
                        }
                        
                        $results[] = $child;
                    }
                }
            }
            
            if ($idx !== null) {
                return $results[$idx] ?? null;
            }
            
            return $results;
        }
        
        function text() {
            return $this->text ?? '';
        }
        
        function innertext() {
            if (isset($this->innertext)) {
                return $this->innertext;
            }
            $text = '';
            foreach ($this->children as $child) {
                $text .= $child->outertext();
            }
            return $text;
        }
        
        function outertext() {
            if (isset($this->outertext)) {
                return $this->outertext;
            }
            return $this->text ?? '';
        }
        
        function href() {
            return $this->attr['href'] ?? null;
        }
        
        function src() {
            return $this->attr['src'] ?? null;
        }
        
        function getAttribute($name) {
            return $this->attr[$name] ?? null;
        }
        
        function __get($name) {
            if ($name === 'href') return $this->href();
            if ($name === 'src') return $this->src();
            if ($name === 'plaintext') return $this->text();
            return null;
        }
    }
    
    /**
     * Simple HTML DOM - Minimal Parser
     */
    class simple_html_dom {
        private $root;
        
        function __construct($str = '') {
            $this->root = new simple_html_dom_node();
            $this->root->tag = 'root';
            
            if ($str) {
                $this->load($str);
            }
        }
        
        function load($str) {
            // Very basic HTML parsing
            $this->root = $this->parse($str);
            return $this;
        }
        
        private function parse($str, $parent = null) {
            $node = new simple_html_dom_node();
            
            // Strip script and style tags
            $str = preg_replace('/<script[^>]*>.*?<\/script>/is', '', $str);
            $str = preg_replace('/<style[^>]*>.*?<\/style>/is', '', $str);
            
            // Find all tags
            $pattern = '/<([a-z][a-z0-9-]*)([^>]*)>([\s\S]*?)<\/\1>/i';
            
            if (preg_match_all($pattern, $str, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    $tag = strtolower($match[1]);
                    $attrs = $match[2];
                    $content = $match[3];
                    
                    $child = new simple_html_dom_node();
                    $child->tag = $tag;
                    $child->outertext = $match[0];
                    $child->innertext = $content;
                    
                    // Parse attributes
                    if (preg_match_all('/([a-z-]+)=["\']([^"\']*)["\']/i', $attrs, $attrMatches, PREG_SET_ORDER)) {
                        foreach ($attrMatches as $am) {
                            $child->attr[strtolower($am[1])] = $am[2];
                        }
                    }
                    
                    // Get text content (strip tags)
                    $child->text = strip_tags($content);
                    
                    // Parse children recursively
                    $child->children = $this->parse($content, $child);
                    
                    if ($parent) {
                        $child->parent = $parent;
                        $parent->children[] = $child;
                    }
                }
            }
            
            // Handle self-closing tags and text nodes
            $textPattern = '/>([^<]+)</';
            if (preg_match_all($textPattern, $str, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $match) {
                    $text = trim($match[1]);
                    if ($text && $parent) {
                        $textNode = new simple_html_dom_node();
                        $textNode->text = $text;
                        $textNode->tag = 'text';
                        $textNode->parent = $parent;
                        $parent->children[] = $textNode;
                    }
                }
            }
            
            return $parent ? $parent->children : $node;
        }
        
        function find($selector, $idx = null) {
            return $this->root->find($selector, $idx);
        }
        
        function __get($name) {
            if ($name === 'root') return $this->root;
            return null;
        }
    }
    
    // Helper function to create from string
    function str_get_html($str) {
        return new simple_html_dom($str);
    }
}
